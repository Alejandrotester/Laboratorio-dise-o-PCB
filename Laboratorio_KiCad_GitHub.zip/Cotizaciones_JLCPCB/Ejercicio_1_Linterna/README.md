Añadir aquí las capturas de cotización JLCPCB de la PCB y los archivos Gerber exportados. Para el ejercicio 3, incluir además la cotización PCBA (BOM y CPL verificados).
