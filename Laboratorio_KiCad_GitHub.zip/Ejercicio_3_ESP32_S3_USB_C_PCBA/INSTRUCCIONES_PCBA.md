# Cotización PCBA — Ejercicio 3

La BOM de ejemplo `BOM_BORRADOR_NO_SUBIR_DIRECTAMENTE.csv` se extrajo de las 32 huellas reales del PCB proporcionado. Es **un inventario preliminar y NO es una BOM completa para fabricar**: todos los códigos `JLCPCB Part #` están vacíos y faltan especificaciones como tensión, tolerancia, polaridad, fabricante y MPN. No suponga que dos componentes con la misma huella son intercambiables.

- 30 componentes en cara superior F.Cu (incluyendo 2 pulsadores THT).
- 2 cabezales pasantes J4/J5 de 15 posiciones asociados a huellas B.Cu (montaje inferior).
- 2 pulsadores THT SW1/SW2 cara F.Cu.
- Total: 32 referencias en el PCB (30 en F.Cu y 2 en B.Cu).

**Importante:** recalcular cantidades según la selección de ensamblaje y solicitar si JLCPCB admite esos conectores/pulsadores en la cara elegida. No afirmar PCBA completo si JLCPCB deja componentes no seleccionados.

## Exportación preferida desde KiCad 10

1. Abrir el PCB del ejercicio 3 y sincronizar con el esquemático (`F8` desde el esquema).
2. Administrador de Complementos y Contenido → buscar e instalar `Fabrication Toolkit`.
3. Regresar al editor PCB y pulsar el icono de Fabrication Toolkit.
4. Activar actualización de zonas y correcciones automáticas de posiciones/rotaciones.
5. Generar `gerber.zip`, `bom.csv` y `positions.csv`.
6. Completar códigos LCSC con piezas que coincidan exactamente en hoja de datos, huella y especificaciones.
7. Revisar visualmente todas las orientaciones de polarizados y THT en el visor PCBA de JLCPCB.

También se puede obtener BOM mediante Herramientas → Tabla de campos de símbolos → Exportar CSV, y CPL mediante Archivo → Salidas de fabricación → Archivos de posición de componentes; en este caso se deben adaptar las cabeceras a JLCPCB.
